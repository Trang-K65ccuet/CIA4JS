const VCUploadDataManager = {
    projectName: null,
    versionName: "v1.0",
    isNewVersionMode: false
};

export default VCUploadDataManager;