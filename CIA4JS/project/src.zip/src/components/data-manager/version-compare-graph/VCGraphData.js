export const VCGraphData = {
    graph: null,
    graphData: null,
}