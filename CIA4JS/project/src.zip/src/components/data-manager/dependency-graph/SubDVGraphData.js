const SubDVGraphData = {
    graph: null,
    graphData: null,
};

export default SubDVGraphData;