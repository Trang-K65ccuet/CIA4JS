const DVGraphData = {
    graph: null,
    graphData: null,
}

export default DVGraphData;