export const GitServiceData = {
    access_token: null,
    user: null,
    userRepos: [],
}