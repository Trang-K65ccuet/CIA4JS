const XML_TYPE = {
    XML_ROOT_NODE: "XmlRootNode",
    XML_FILE_NODE: "XmlFileNode",
    XML_TAG_NODE: "XmlTagNode"
}

export default XML_TYPE;