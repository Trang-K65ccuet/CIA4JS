const ProjectDataManager = {
    projectList: [],
}

export default ProjectDataManager;