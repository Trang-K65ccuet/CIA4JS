const License = {
    mount() {

    },

    unMount() {

    },

    createView() {

    }
}

export default License;