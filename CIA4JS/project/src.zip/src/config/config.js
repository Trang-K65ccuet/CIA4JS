const SystemConfig = {
    PROJECT_DIRECTORY_ROOT : "./project/anonymous",
    FROM_PC_PROJECT_DIRECTORY_ROOT : "./project/anonymous/tmp-prj",
}

export default SystemConfig;