const Message = {
    GIT_MESSAGE: {
        ERROR_NOT_SAME_TYPE: "Please make sure that two version are the same type.",
        ERROR_NOT_SAME_TYPE_EXAMPLE: "Example: branch - branch or commit - commit.",
    }
}
export default Message;