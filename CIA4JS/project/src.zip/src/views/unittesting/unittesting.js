import {auth} from "../../app";
import { UnitTestingTemplate } from "../../components/unit-testing/template/UnitTestingTemplate";
import Utils from "../../components/utils/BasicUltils";
import { DOMUtils } from "../../components/utils/DOMUtils";

const UnitTesting = {
    mount() {
       
    },
    unMount() {
        
    },
    createView() {

    }
}

export default UnitTesting;