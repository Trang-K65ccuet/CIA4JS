const FromPcDataManager = {
    projectName: null,
    versionName: null,
    isNewVersionMode: false,
    language: null,
};

export default FromPcDataManager;