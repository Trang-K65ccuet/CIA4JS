const BootstrapToast = {
    createToast(parentDomEle, data) {
        let parentDom = parentDomEle;

    }
};

export default BootstrapToast;