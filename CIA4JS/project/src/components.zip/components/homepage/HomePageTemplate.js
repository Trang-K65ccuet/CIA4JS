export const HomePageTemplate = `
     <div class="homepage-wrapper">
            <div class="img">
                <img src="https://raw.githubusercontent.com/thdtt/JCIA-Assets/d12e001221166702c24685a8ca0365b41f0e5bf8/bg.svg">
            </div>
            <div class="homepage-content">
                <div class="welcome">Welcome to JCIA</div>
                <div class="recent-projects"></div>
            </div>
            <div class="accordion" id="accordionExample">
</div>
        </div>
`;