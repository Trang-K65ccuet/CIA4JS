import VIEW_CONFIG_VARIABLES from "../../../config/ViewConfig";

export const VIEW_IDS = {
    DEPENDENCY_VIEW_ID: "dependency",
    SUB_DEPENDENCY_VIEW_ID: "sub-node-view",
    SUB_DEPENDENCY_VIEW_IMPACT_ID: "sub-node-impact-view",
    SOURCE_CODE_VIEW_ID : "source-code",
    VERSION_COMPARE_ID : "version-compare",
};




