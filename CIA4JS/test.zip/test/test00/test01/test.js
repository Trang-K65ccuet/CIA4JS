// Định nghĩa lớp Square
class Square {
    constructor(side) {
      this.side = side;
    }
  
    getArea() {
      return this.side * this.side;
    }
  
    getPerimeter() {
      return 4 * this.side;
    }
  }
  

  
  // Tạo một đối tượng Square
  const square = new Square(5);
  
  // Gọi các phương thức và in kết quả ra console
  const area = square.getArea();
  
  const perimeter = square.getPerimeter();

  // Hàm tính tổng của hai số
function sum() {
  return a + b;
}

function printSum() {
  const result= sum(x, y);
  console.log("Tổng hai số là: " + result);
}

