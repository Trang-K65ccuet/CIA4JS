// Khai báo lớp cha
class Animals {
    constructor(name) {
      this.name = name;
    }
  
    eat() {
      console.log(`${this.name} is eating.`);
    }
  }
  
  // Khai báo lớp con kế thừa từ lớp cha Animal
  class Dog extends Animals {
    constructor(name, breed) {
      super(name);
      this.breed = breed;
    }
  
    bark() {
      console.log(`${this.name} is barking.`);
    }
  }
  
  // Khai báo một đối tượng
  const myDog = new Dog("Max", "Labrador");
  
  // Gọi phương thức của lớp con
  myDog.bark();
  
  // Gọi phương thức của lớp cha thông qua kế thừa
  myDog.eat();
  
  // Override phương thức của lớp cha
  class Cat extends Animals {
    constructor(name) {
      super(name);
    }
  
    // Override phương thức eat của lớp cha
    eat() {
      console.log(`${this.name} is eating fish.`);
    }
  }
  
  // Khai báo một đối tượng mới từ lớp Cat
  const myCat = new Cat("Whiskers");
  
  // Gọi phương thức overridden của lớp con Cat
  myCat.eat();
  