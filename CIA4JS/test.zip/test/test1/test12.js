// Lớp cha
class Animal {
    constructor(name) {
      this.name = name;
    }
  
    makeSound() {
      console.log("Âm thanh chung của động vật");
    }
  }
  
  // Lớp con kế thừa từ lớp cha
  class Dog extends Animal {
    constructor(name) {
      super(name);
    }
  
    createAnimal(animal) {
        
    }
    // Ghi đè phương thức makeSound()
    makeSound() {
      console.log("Gâu gâu!");
    }
  }
  
  // Tạo một đối tượng từ lớp con
  const myDog = new Dog("Bobby");
  
  // Gọi phương thức makeSound() trên đối tượng
  myDog.makeSound(); // Kết quả: "Gâu gâu!"