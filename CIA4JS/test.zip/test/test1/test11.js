// Khai báo một enum
const Colors = {
    RED: 'red',
    GREEN: 'green',
    BLUE: 'blue'
  };
  
  // Khai báo một lớp Person
  class Person {
    constructor(name, age) {
      this.name = name;
      this.age = age;
    }
  
    // Phương thức instance của lớp Person
    sayHello() {
      console.log(`Hello, my name is ${this.name} and I'm ${this.age} years old.`);
    }
  
    // Getter và setter cho thuộc tính name
    get personName() {
      return this.name;
    }
  
    set personName(newName) {
      this.name = newName;
    }
  
    // Phương thức tĩnh của lớp Person
    static staticMethod() {
      console.log('This is a static method of Person class.');
    }
  }
  
  // Gọi các phương thức và in kết quả ra console
  const john = new Person('John Doe', 25);
  john.sayHello();
  
  john.personName = 'John Smith';
  
  Person.staticMethod();
  
  console.log(Colors.RED);