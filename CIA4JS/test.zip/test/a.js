  // Ví dụ: Một lớp Order sử dụng lớp Product để tính toán tổng giá trị đơn hàng


  class Order {
    constructor(products) {
      this.products = products;
    }
  
  
    calculateTotal() {
      let total = 0;
      this.products.forEach(product => {
        total += product.price;
      });
      return total;
    }
  }
  
  
  class Product {
    constructor(name, price) {
      this.name = name;
      this.price = price;
    }

    hello() {
      const a = new Order(products);
      a.calculateTotal();
      console.log(a);
    }
  }
  
  
  const products = [
    new Product('Product 1', 10),
    new Product('Product 2', 20),
    new Product('Product 3', 30)
  ];
  
  
  const order = new Order(products);
  console.log(order.calculateTotal()); // Output: 60