const message = "Hello, world!";
function a() {
console.log(message); 
}